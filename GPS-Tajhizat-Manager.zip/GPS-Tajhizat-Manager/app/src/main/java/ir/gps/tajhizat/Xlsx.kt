package ir.gps.tajhizat

import android.content.Context
import android.net.Uri
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream
import java.util.zip.ZipEntry

/**
 * Small dependency-free XLSX reader/writer for the app's simple 11-column template.
 * Import supports sharedStrings and inline strings in the first worksheet.
 */
object Xlsx {
    val headers = listOf("کد تجهیز","نام تجهیز","نوع تجهیز","نام شهر","نشانی","Latitude","Longitude","وضعیت تجهیز","تاریخ آخرین بازدید","توضیحات","اقدامات انجام‌شده")
    private fun readEntry(zip: ZipInputStream, wanted: String): String? {
        var e = zip.nextEntry
        while (e != null) {
            if (e.name == wanted) return zip.readBytes().toString(Charsets.UTF_8)
            e = zip.nextEntry
        }
        return null
    }
    private fun entries(input: InputStream): Map<String, ByteArray> {
        val m = linkedMapOf<String, ByteArray>()
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) { if (!e.isDirectory) m[e.name] = z.readBytes(); e = z.nextEntry }
        }
        return m
    }
    private fun parseXml(xml: String, tag: String): List<String> {
        val result = mutableListOf<String>()
        val p = Xml.newPullParser()
        p.setInput(xml.reader())
        var inside = false
        val sb = StringBuilder()
        var event = p.eventType
        while (event != XmlPullParser.END_DOCUMENT) {
            if (event == XmlPullParser.START_TAG && p.name == tag) { inside = true; sb.setLength(0) }
            else if (inside && event == XmlPullParser.TEXT) sb.append(p.text)
            else if (inside && event == XmlPullParser.END_TAG && p.name == tag) { result += sb.toString(); inside = false }
            event = p.next()
        }
        return result
    }
    fun import(context: Context, uri: Uri, db: EquipmentDb, replaceExisting: Boolean): Pair<Int, Int> {
        val input = context.contentResolver.openInputStream(uri) ?: error("فایل باز نشد")
        val m = input.use { entries(it) }
        val shared = m["xl/sharedStrings.xml"]?.let { parseXml(it.toString(Charsets.UTF_8), "t") } ?: emptyList()
        val sheet = m["xl/worksheets/sheet1.xml"]?.toString(Charsets.UTF_8) ?: error("برگه اول اکسل پیدا نشد")
        val p = Xml.newPullParser(); p.setInput(sheet.reader())
        val rows = mutableListOf<MutableMap<Int,String>>()
        var row: MutableMap<Int,String>? = null
        var cellRef = ""; var cellType = ""; var inV = false; var inT = false; val value = StringBuilder()
        var event = p.eventType
        while(event != XmlPullParser.END_DOCUMENT) {
            when(event) {
                XmlPullParser.START_TAG -> when(p.name) {
                    "row" -> row = mutableMapOf()
                    "c" -> { cellRef = p.getAttributeValue(null,"r") ?: ""; cellType = p.getAttributeValue(null,"t") ?: ""; value.setLength(0) }
                    "v" -> inV = true
                    "t" -> if(cellType == "inlineStr") inT = true
                }
                XmlPullParser.TEXT -> if(inV || inT) value.append(p.text)
                XmlPullParser.END_TAG -> when(p.name) {
                    "v" -> inV = false
                    "t" -> inT = false
                    "c" -> {
                        val col = cellRef.takeWhile { it.isLetter() }.fold(0) { a,ch -> a*26+(ch.uppercaseChar()-'A'+1) }-1
                        val raw = value.toString()
                        val resolved = if(cellType=="s") raw.toIntOrNull()?.let { shared.getOrNull(it) } ?: "" else raw
                        row?.put(col,resolved)
                    }
                    "row" -> { if(row != null) rows += row!!; row = null }
                }
            }
            event = p.next()
        }
        var added=0; var skipped=0
        rows.drop(1).forEach { r ->
            fun s(i:Int)=r[i]?.trim().orEmpty()
            val code=s(0)
            val lat=s(5).replace(',','.').toDoubleOrNull()
            val lon=s(6).replace(',','.').toDoubleOrNull()
            if(code.isBlank() || lat==null || lon==null || lat !in -90.0..90.0 || lon !in -180.0..180.0) { skipped++; return@forEach }
            val before = db.count()
            db.upsert(Equipment(code,s(1),s(2),s(3),s(4),lat,lon,s(7),s(8),s(9),s(10)), replaceExisting)
            if(db.count()>before) added++ else if(!replaceExisting) skipped++
        }
        return added to skipped
    }
    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    fun export(out: OutputStream, rows: List<Equipment>) {
        val all = listOf(headers) + rows.map { listOf(it.code,it.name,it.type,it.city,it.address,it.lat.toString(),it.lon.toString(),it.status,it.visitDate,it.notes,it.actions) }
        fun col(n:Int):String { var x=n+1; var s=""; while(x>0){val r=(x-1)%26;s=('A'+r)+s;x=(x-1)/26};return s }
        val sheet = buildString {
            append("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>""")
            all.forEachIndexed { ri, row ->
                append("<row r=\"${ri+1}\">")
                row.forEachIndexed { ci, v -> append("<c r=\"${col(ci)}${ri+1}\" t=\"inlineStr\"><is><t>${esc(v)}</t></is></c>") }
                append("</row>")
            }
            append("</sheetData></worksheet>")
        }
        ZipOutputStream(out).use { z ->
            fun entry(name:String, content:String) { z.putNextEntry(ZipEntry(name)); z.write(content.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            entry("[Content_Types].xml","""<?xml version="1.0" encoding="UTF-8"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/></Types>""")
            entry("_rels/.rels","""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            entry("xl/workbook.xml","""<?xml version="1.0" encoding="UTF-8"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="تجهیزات" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            entry("xl/_rels/workbook.xml.rels","""<?xml version="1.0" encoding="UTF-8"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/></Relationships>""")
            entry("xl/worksheets/sheet1.xml",sheet)
        }
    }
}
